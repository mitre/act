G-02	Capabilities and Controls Matrix	G-02 - ACT Capabilities and Controls Matrix.xlsx
P-02	Preliminary Discussion Presentation	P-02 - SYSTEMNAME ACT Preliminary Discussion Presentation YYYYMMDD.pptx
W-01	Readiness Review Presentation	W-01 - SYSTEMNAME ACT Readiness Review Presentation YYYYMMDD.pptx
W-02	Assessment Kick-Off Presentation	W-02 - SYSTEMNAME ACT Assessment Kick-Off Presentation YYYYMMDD.pptx
